# playlist-php

## Install

```bash
> composer install
```

## Usage

```bash
> php index.php https://morow.com/streams.json m3u
> php index.php https://morow.com/streams.json xspf
```

## Cs-fixer

```bash
> vendor/bin/php-cs-fixer fix
```
